package com.example.android.covidhack;

public class GpsUtils {

}

